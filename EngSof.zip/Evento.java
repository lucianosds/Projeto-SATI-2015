public class Evento {

    protected int IdEvento;
    protected String NomeEvento;
    protected String NomePalestrante;
    protected String Descricao;
    protected String DtHrInicio;
    protected String DtHrFim; // Previsão de término.

  // método construtor
  public Evento (int IdEvento, String NomeEvento, String NomePalestrante, String Descricao, String DtHrInicio, String DtHrFim){
    this.IdEvento = IdEvento;
    this.NomeEvento = NomeEvento;
    this.NomePalestrante = NomePalestrante;
    this.Descricao = Descricao;
    this.DtHrInicio = DtHrInicio;
    this.DtHrFim = DtHrFim;
  }

  // Declaração de funções
  // métodos get
  public String getNomeEvento(){
    return NomeEvento;
  }

  public String getDescricao(){
    return Descricao;
  }


}
