public class Inscricao {

  protected int IdInscricao;
  protected String Participante;
  protected String Evento; //pode ser uma PALESTRA ou MINICURSO, variando com a ocorrencia do pgto ou não
  protected int Status;

  // método construtor
  public Inscricao (int IdInscricao, String Participante, String Evento, int Status){
    this.IdInscricao = IdInscricao;
    this.Participante = Participante;
    this.Evento = Evento;
    this.Status = Status;
  }

  // Declaração de funções
  // métodos get
  public String getParticipante(){
    return Participante;
  }

  public String getEvento(){
    return Evento;
  }

  public String getstatus(){
    if(Status==1){
        return System.out.println("O participante " + Participante + " está com a inscrição OK!")
    }else{
        return System.out.println("O participante " + Participante + " está com problemas com a inscrição.")
    }
  }
}
