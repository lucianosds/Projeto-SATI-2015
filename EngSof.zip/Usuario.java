
public class Usuario {

	protected int IdUsuario;
	protected String Nome;
	protected String Genero;
	protected String RG;
	protected int CPF;
	protected String Email;
	
	public Usuario(int IdUsuario, String Nome, String Genero, String RG, int CPF, String Email){
		this.IdUsuario = IdUsuario;
		this.Nome = Nome;
		this.Genero = Genero;
		this.RG = RG;
		this.CPF = CPF;
		this.Email = Email;
	}
	
}
